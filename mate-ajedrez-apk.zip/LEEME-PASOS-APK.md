# Mate · Tutor de ajedrez — cómo convertirlo en APK

Esta carpeta ya está lista: GitHub construye el APK por ti, gratis y sin instalar nada.
La app funciona **sin internet** (el "cerebro" de ajedrez va dentro).

## Qué necesitas
- Una cuenta en https://github.com (gratis).
- Un computador para subir los archivos (desde el celular es muy incómodo).

## Paso a paso

1. **Descomprime** el ZIP en tu computador. Verás: `www/`, `package.json`, `capacitor.config.json`,
   `.gitignore`, `.github/` y este archivo.
   > Si no ves `.github`, activa "mostrar archivos ocultos" (Windows: pestaña *Vista → Elementos ocultos*;
   > Mac: `Cmd + Shift + .`).
2. En GitHub pulsa **+ → New repository**. Ponle un nombre (ej. `mate-ajedrez`), déjalo **Public**
   o Private, y pulsa **Create repository**.
3. En la página del repositorio nuevo pulsa **uploading an existing file**.
4. **Arrastra TODO el contenido** de la carpeta descomprimida (incluida `.github`) a la ventana y
   pulsa **Commit changes**.
   > Comprueba que en el repositorio aparezca el archivo `.github/workflows/android.yml`.
   > Si no apareció: **Add file → Create new file**, escribe como nombre `.github/workflows/android.yml`
   > y pega dentro el contenido de `android-workflow-copia.yml` (viene en este ZIP).
5. Ve a la pestaña **Actions**. Verás "Crear APK" ejecutándose (tarda unos 5–8 minutos).
   Si no arrancó sola: entra en "Crear APK" → **Run workflow**.
6. Cuando salga el ✅ verde, abre esa ejecución y baja hasta **Artifacts**.
   Descarga **mate-ajedrez-apk** (es un ZIP que contiene `app-debug.apk`).
7. Pasa `app-debug.apk` a tu celular (cable, Drive, WhatsApp a ti mismo…) y ábrelo.
   Android te pedirá **permitir instalar apps de esta fuente**: acéptalo. Listo.

## Si algo falla
- ❌ rojo en Actions: abre el paso que falló y copia el texto del error para mandármelo.
- "App no instalada": desinstala una versión anterior y vuelve a instalar.
- Es un APK de **depuración** (sirve para instalar y usar). Para subirlo a Google Play hay que firmarlo;
  eso se puede hacer después.

## Para actualizar la app
Cambia `www/index.html` en GitHub (o sube el nuevo) → Actions crea un APK nuevo solo.
